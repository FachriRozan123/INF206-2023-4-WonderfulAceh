<?php $__env->startSection('content'); ?>
    <div class="col">
        <h2>DAFTAR TEMPAT WISATA</h2>
        <form action="<?php echo e(route('holiday.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="image" class="col-sm-2 col-form-label">Image</label>
                <div class="col-sm-10">
                    <input name="image" type="file" class="form-control-file" id="image">
                    <small class="form-text text-muted">Upload an image for the place.</small>
                </div>
            </div>
            <div class="form-group row">
                <label for="nama_tempat" class="col-sm-2 col-form-label">Nama Tempat</label>
                <div class="col-sm-10">
                    <input name="nama_tempat" type="text" class="form-control" />
                </div>
            </div>
            <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-10">
                    <input name="alamat" type="text" class="form-control" />
                </div>
            </div>
            <div class="form-group row">
                <label for="nama_pemilik" class="col-sm-2 col-form-label">Nama Pemilik</label>
                <div class="col-sm-10">
                    <input name="nama_pemilik" type="text" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label for="nomor_pemilik" class="col-sm-2 col-form-label">Nomor Pemilik</label>
                <div class="col-sm-10">
                    <input name="nomor_pemilik" type="text" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label for="kategori" class="col-sm-2 col-form-label">Kategori</label>
                <div class="col-sm-10">
                    <input name="kategori" list="kategori" type="select" class="form-control"/>
                    <datalist id="kategori">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->category); ?>"></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist> 
                </div>
            </div>
            <div class="form-group row">
                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                <div class="col-sm-10">
                    <textarea name="deskripsi" class="form-control" rows="5"></textarea>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary float-right" style="margin-right: 5px;">Daftar</button>
                    <a href="/" class="btn btn-secondary float-right" style="margin-left: 5px;">Cancel</a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\-2023-4-WonderfulAceh\resources\views/holiday/addTempat.blade.php ENDPATH**/ ?>