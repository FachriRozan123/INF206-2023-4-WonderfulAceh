<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tempat</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/348c676099.js" crossorigin="anonymous"></script>
</head>
<body>
    <main style=" background-color:#1f4847  !important;">
        <div style="text-align:left;">
            <h1 style="font-size:2rem;color:rgb(255, 255, 255); padding-left: 20px;">
                Nama Tempat
            </h1>
             <div class="row" style="justify-content: center;">
                <div class="col" style="position: relative; left: 20px;">
                  <a href=".html" class="text-decoration-none">
                    <div
                      style="display: inline-block; height: 300px; width: 1420px; background-color: white; border-radius: 0%; overflow: hidden; padding: 6px;">
                      <a href=".html" class="text-decoration-none">
                          <img src="img/pantai.jpg" style="height: 270px; width: 25%; margin-top: 10px;">
                          </a>
                          <div style="position: absolute; top: 40px; left: 27%; text-align: center;">
                            <h4>Nama:</h4>
                            <div style="position: absolute; top: 60px; text-align: center;">
                            <h4>Kategori:</h4>
                            <div style="position: absolute; top: 60px; text-align: center;">
                            <h4>Deskripsi:</h4>
                       </div>
                       </div>
                       </div>
                       </a>
                    </div>
                </div>
             </div>
        <div class="row" style="display: flex; justify-content: space-between;">
            <div class="col" style="position: relative; left: 20px;">
                <a href=".html" class="text-decoration-none">
                    <h1 style="font-size:2rem;color:rgb(255, 255, 255); padding-left: 2px;">
                        Nama Tempat
                    </h1>
                    <div style="display: flex; height: 200px; width: 320px; background-color: rgb(255, 253, 253); border-radius: 0%; overflow: hidden; padding: 15px;">
                    <img src="img/user.png" style="height: 110px; width: 40%;">
                    <h3 style="color: black;">Nama</h3>
                    <img src="img/chat.png" style="height: 60px; width: 30%; margin-top: 100px;">
                </div>
                </a>
            </div>
            <div class="col" style="position: relative; margin-left: 750px; ">
                <a href=".html" class="text-decoration-none">
                    <h1 style="font-size:2rem;color:rgb(255, 255, 255); padding-left: 2px;">
                        Tour Guide
                    </h1>
                    <div style="display: flex; height: 200px; width: 320px; background-color: rgb(255, 253, 253); border-radius: 0%; overflow: hidden; padding: 15px;">
                        <img src="img/user.png" style="height: 110px; width: 40%;">
                        <h3 style="color: black;">Nama</h3>
                        <img src="img/chat.png" style="height: 60px; width: 30%; margin-top: 100px;">
                    </div>
                </a>
            </div>
        </div>
        </div>
        <br>
        <br>
        <br>
        
    
    </main>

    <footer class="bg-white text-center pt-">
        <p> Copyright 2023 &copy; WonderfulAceh</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\INF206-2023-C-WonderfulAceh\INF206-2023-4-WonderfulAceh\resources\views/tempat.blade.php ENDPATH**/ ?>