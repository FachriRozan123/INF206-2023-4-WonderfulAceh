<?php $__env->startSection('content'); ?>
    <!doctype html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Tempat</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
            integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/348c676099.js" crossorigin="anonymous"></script>
    </head>

    <body>
        
        <main style=" background-color:#1f4847  !important;">
            <div style="text-align:left;">
                <h1 style="font-size:2rem;color:rgb(255, 255, 255); padding-left: 20px;">
                    <?php echo e($tempat[0]->nama_tempat); ?>

                </h1>
                <div class="row" style="justify-content: center;">
                    <div class="col" style="position: relative; left: 20px;">
                        <a class="text-decoration-none">
                            <div
                                style="display: flex; height: 300px; width: 1420px; background-color: white; border-radius: 0%; overflow: hidden; padding: 6px;">
                                <a class="text-decoration-none">
                                    <img src="<?php echo e(asset($tempat[0]->image)); ?>"
                                        style="height: 270px; width: 100%; margin-top: 10px;">
                                </a>
                                <div style="position: relative; margin-left: 20px; text-align: left;">
                                <br>
                                    <h4>Nama: <?php echo e($tempat[0]->nama_tempat); ?></h4>
                                    <h4>Kategori: <?php echo e($tempat[0]->category->category); ?></h4>
                                    <h4>Deskripsi: <?php echo e($tempat[0]->deskripsi); ?></h4>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <br>
            <div class="row" style="display: flex; justify-content: space-between;">
                <div class="col" style="position: relative; left: 20px;">
                    <a class="text-decoration-none">
                        <h1 style="font-size: 2rem; color: rgb(255, 255, 255); padding-left: 2px;">Pemilik Tempat</h1>
                        <div style="display: flex; align-items: center; height: 200px; width: 320px; background-color: rgb(255, 253, 253); border-radius: 0%; overflow: hidden; padding: 15px;">
                            <img src="/img/user.png" style="height: 110px; width: 40%;">
                            <div style="margin-left: 20px;">
                                <h3 style="color: black;"><?php echo e($tempat[0]->nama_pemilik); ?>&nbsp;</h3>
                                <img src="/img/chat.png" style="height: 60px; width: 30%; margin-top: 10px;">
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col" style="position: relative; margin-left: auto; right: -450px;">
                    <a class="text-decoration-none">
                        <h1 style="font-size: 2rem; color: rgb(255, 255, 255); padding-left: 2px;">Tour Guide</h1>
                        <div style="display: flex; align-items: center; height: 200px; width: 320px; background-color: rgb(255, 253, 253); border-radius: 0%; overflow: hidden; padding: 15px;">
                            <img src="/img/user.png" style="height: 110px; width: 40%;">
                            <div style="margin-left: 20px;">
                                <h3 style="color: black;">Personal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h3>
                                <img src="/img/chat.png" style="height: 60px; width: 30%; margin-top: 10px;">
                            </div>
                        </div>
                    </a>
                </div>                
            </div>            
        </main>

        <footer class="bg-white text-center pt-">
            <p> Copyright 2023 &copy; WonderfulAceh</p>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
        </script>
    </body>

    </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\-2023-4-WonderfulAceh\resources\views/holiday/tempat.blade.php ENDPATH**/ ?>