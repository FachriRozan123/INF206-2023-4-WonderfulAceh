<?php $__env->startSection('content'); ?>
    <!doctype html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>ThisOrThat</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
            integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/348c676099.js" crossorigin="anonymous"></script>
    </head>

    <body>
        
        <main style=" background-color:#1f4847  !important;">
            <br>
            <br>
            <br>
            <div style="text-align: center;">
                <h1 style="font-size:3rem;color:white;">
                    This Or That
                </h1>
                <br>
                <br>
                <div class="row" style="justify-content: center;">
                    <div class="col" style="position: relative;left: 200px;">
                        <a  class="text-decoration-none">
                            <span
                                style="display: inline-block; height: 250px; width: 250px; background-color: white; border-radius: 100%; overflow: hidden;padding: 50px center;">
                                <img src="<?php echo e(asset($category[0]->image)); ?>" style="height: 100%; width: auto;">
                            </span>
                            <br>
                            <br>
                            <br>
                            <p class="text-white">
                                <?php echo e($category[0]->category); ?>

                            </p>
                        </a>
                    </div>
                    <div class="col">
                        <span style="padding: 0 150px 0 150px;border-top: 1px solid none;position: relative;top: 120px;">
                        </span>
                    </div>

                    <div class="col" style="position: relative;right: 200px;">
                        <span
                            style="display: inline-block; height: 250px; width: 250px; background-color: white; border-radius: 100%; overflow: hidden;padding: 50px center;">
                            <img src="<?php echo e(asset($category[1]->image)); ?>" style="height: 100%; width: 100%;">
                        </span>
                        <br>
                        <br>
                        <br>
                        <p class="text-white">
                            <?php echo e($category[1]->category); ?>

                        </p>
                        </a>
                    </div>
                </div>
                <div class="row" style="justify-content: center;">
                    <div class="col" style="position: relative;left: 200px;">
                        <a href=".html" class="text-decoration-none">
                            <span
                                style="display: inline-block; height: 250px; width: 250px; background-color: white; border-radius: 100%; overflow: hidden;padding: 50px center;">
                                <img src="<?php echo e(asset($category[2]->image)); ?>" style="height: 100%; width: auto;">
                            </span>
                            <br>
                            <br>
                            <br>
                            <p class="text-white">
                                <?php echo e($category[2]->category); ?>

                            </p>
                        </a>
                    </div>
                    <div class="col">
                        <span style="padding: 0 150px 0 150px;border-top: 1px solid none;position: relative;top: 120px;">
                        </span>
                    </div>

                    <div class="col" style="position: relative;right: 200px;">
                        <span
                            style="display: inline-block; height: 250px; width: 250px; background-color: white; border-radius: 100%; overflow: hidden;padding: 50px center;">
                            <img src="<?php echo e(asset($category[3]->image)); ?>" style="height: 100%; width: 100%;">
                        </span>
                        <br>
                        <br>
                        <br>
                        <p class="text-white">
                            <?php echo e($category[3]->category); ?>

                        </p>
                        </a>
                    </div>
                    <div class="row" style="justify-content: center;">
                        <div class="col" style="position: relative;left: 200px;">
                            <a href=".html" class="text-decoration-none">
                                <span
                                    style="display: inline-block; height: 250px; width: 250px; background-color: white; border-radius: 100%; overflow: hidden;padding: 50px center;">
                                    <img src="<?php echo e(asset($category[4]->image)); ?>" style="height: 100%; width: auto;">
                                </span>
                                <br>
                                <br>
                                <br>
                                <p class="text-white">
                                    <?php echo e($category[4]->category); ?>

                                </p>
                            </a>
                        </div>
                        <div class="col">
                            <span
                                style="padding: 0 150px 0 150px;border-top: 1px solid none;position: relative;top: 120px;">
                            </span>
                        </div>

                        <div class="col" style="position: relative;right: 200px;">
                            <span
                                style="display: inline-block; height: 250px; width: 250px; background-color: white; border-radius: 100%; overflow: hidden;padding: 50px center;">
                                <img src="<?php echo e(asset($category[5]->image)); ?>" style="height: 100%; width: 100%;">
                            </span>
                            <br>
                            <br>
                            <br>
                            <p class="text-white">
                                <?php echo e($category[5]->category); ?>

                            </p>
                            </a>
                        </div>
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit" n>Submit</button>
                    </div>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div>    
        </main>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
        </script>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\INF206-2023-C-WonderfulAceh\INF206-2023-4-WonderfulAceh\resources\views/holiday/thisorthat.blade.php ENDPATH**/ ?>